package com.pocketporter.partner;

public class Constants {
    static final  int Location_service_id=175;
    static final  String Action_start_service="starlocationtservice";
    static final  String Action_stop_service="stoplocationservice";
}
